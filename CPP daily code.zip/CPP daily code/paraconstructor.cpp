// parameterised constructor and copy constructor
#include<iostream>
using namespace std;
class square
{
    public:
    int side1,side2,area;
    square(int s1, int s2)
    {
        side1 = s1;
        side2 = s2;
        cout << "parameterised constructor called" << endl;
        area = side1*side2;
        cout << "area: "<< area <<endl;
    }
    square(square &s1)
    {
        side1=s1.side1;
        side2=s2.side2;
        cout <<"copy constructor called"<<endl;
        area = side1*side2;
        cout << "area: "<< area <<endl;
    }
};

int main()
{
    int l,w;
    cout << "enter dimensions: "<< endl;
    cout << "side1: ";
    cin >> l;  // this l will go to square constructor and pass the value of it 
    cout << "side2: ";
    cin >> w; //this w will go to square constructor and pass the value of it
    
    square r1(s1,s2); //object of parameterised constructor
    
    /*objects of copy constructor both should be valid
    square r2(r1);
    //square r2 = r1;
    */
    square r2(r1);
}
    
